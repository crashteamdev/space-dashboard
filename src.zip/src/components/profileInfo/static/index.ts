type IPropsSubs = {
    default: string;
    advanced: string;
    pro: string;
}
export const SUBS_TITLE: IPropsSubs = {
    "default": "БАЗОВЫЙ",
    "advanced": "РАСШИРЕННЫЙ",
    "pro": "ПРОФЕССИОНАЛЬНЫЙ",
};