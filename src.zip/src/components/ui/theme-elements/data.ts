const data = [
  { 
    title: "freekassa", photo: "https://alllogos.ru/images/logotip-free-kassa.png", 
    key: 1 
  },
  {
    title: "СlickPay",
    photo: "https://marketing.uz/uploads/articles/1222/article-original.png",
    key: 2
  }
];

export default data;
