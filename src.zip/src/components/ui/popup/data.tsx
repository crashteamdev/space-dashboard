export const data = ["freekassa", "ClickUp", "Оплата с баланса"];

export const pricing = [
  {
    id: 1,
    package: "Default",
    packageRu: "Базовый",
    monthlyplan: 15,
    discount: 10,
    diccountMath: .10,
    avatar: "/images/backgrounds/silver.png",
    badge: false,
    btntext: "Выбрать",
    rules: [
      {
        limit: true,
        title: "Доступ к расширению"
      },
      {
        limit: true,
        title: "История позиций товара"
      },
      {
        limit: true,
        title: "30 дней периода аналитики"
      },
      {
        limit: true,
        title: "Отчеты по магазинам в формате Excel"
      },
      {
        limit: true,
        title: "Общая аналитика по магазинам"
      },
      {
        limit: true,
        title: "Все магазины продавцов"
      },
      {
        limit: true,
        title: "Общая аналитика по категорииям"
      },
      {
        limit: true,
        title: "Cервис автоматического изменения цен"
      },
      {
        limit: false,
        title: "Отчеты по категориям в формате Excel"
      },
      {
        limit: false,
        title: "Приоритетная поддержка"
      }
    ]
  },
  {
    id: 2,
    package: "Advanced",
    packageRu: "Расширенный",
    monthlyplan: 30,
    discount: 15,
    diccountMath: .15,
    avatar: "/images/backgrounds/bronze.png",
    badge: false,
    btntext: "Выбрать",
    rules: [
      {
        limit: true,
        title: "Доступ к расширению"
      },
      {
        limit: true,
        title: "История позиций товара"
      },
      {
        limit: true,
        title: "30 / 60 / 90 дней периода аналитики"
      },
      {
        limit: true,
        title: "Отчеты по магазинам в формате Excel"
      },
      {
        limit: true,
        title: "Отчеты по категориям в формате Excel"
      },
      {
        limit: true,
        title: "Общая аналитика по магазинам"
      },
      {
        limit: true,
        title: "Все магазины продавцов"
      },
      {
        limit: true,
        title: "Общая аналитика по категорииям"
      },
      {
        limit: true,
        title: "Приоритетная поддержка"
      },
      {
        limit: true,
        title: "Cервис автоматического изменения цен"
      }
    ]
  },
  {
    id: 3,
    package: "Pro",
    packageRu: "Профессиональный",
    monthlyplan: 40,
    discount: 20,
    diccountMath: .20,
    avatar: "/images/backgrounds/gold.png",
    badge: false,
    btntext: "Выбрать",
    rules: [
      {
        limit: true,
        title: "Доступ к расширению"
      },
      {
        limit: true,
        title: "История позиций товара"
      },
      {
        limit: true,
        title: "30 / 60 / 90 / 120 дней периода аналитики"
      },
      {
        limit: true,
        title: "Отчеты по магазинам в формате Excel"
      },
      {
        limit: true,
        title: "Отчеты по категориям в формате Excel"
      },
      {
        limit: true,
        title: "Общая аналитика по магазинам"
      },
      {
        limit: true,
        title: "Все магазины продавцов"
      },
      {
        limit: true,
        title: "Общая аналитика по категорииям"
      },
      {
        limit: true,
        title: "Приоритетная поддержка"
      },
      {
        limit: true,
        title: "Cервис автоматического изменения цен"
      }
    ]
  }
];
