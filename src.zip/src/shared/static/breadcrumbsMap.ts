export const BREADCRUMBS_MAP: Record<string, string> = {
  profile: "Профиль",
};
