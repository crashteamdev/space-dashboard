export type IconType =
    | "lava-pay"
    | "freekassa"
    | "logo"
    | "click-up"
    | "enot";