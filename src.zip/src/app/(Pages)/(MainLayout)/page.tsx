/* eslint-disable xss/no-location-href-assign */
"use client";
// import { useEffect } from "react";

const Dashboard = () => {
    // useEffect(() => {
    //     const newPath = "/profile";
    //     const safePath = encodeURI(newPath);
    //     window.location.href = safePath;
    // }, []);
    return null;
};

export default Dashboard;